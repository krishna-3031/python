from heartrate.core import trace

__version__ = '0.2.2'
